"""
Management command: ``python manage.py chat``

A terminal client for talking to the chat bot. The conversation looks like:

    user: Good morning! How are you doing?
    bot: I am doing very well, thank you for asking.

Type ``quit``, ``exit`` or ``bye`` (or press Ctrl+C / Ctrl+D) to leave.
"""

from django.core.management.base import BaseCommand

from chat.bot import get_chatbot

# Words that end the chat session (compared case-insensitively).
EXIT_COMMANDS = {"quit", "exit", "bye"}


class Command(BaseCommand):
    """Interactive terminal chat with the ChatterBot instance."""

    help = "Start an interactive chat session with the bot in the terminal."

    def add_arguments(self, parser):
        """Register optional command-line flags."""
        parser.add_argument(
            "--read-only",
            action="store_true",
            help="Do not let the bot learn from this conversation.",
        )

    def handle(self, *args, **options):
        """Run the read-respond loop until the user exits."""
        chatbot = get_chatbot(read_only=options["read_only"])

        # Warn the user if the bot has never been trained.
        if chatbot.storage.count() == 0:
            self.stdout.write(self.style.WARNING(
                "The bot has no training data yet. "
                "Run 'python manage.py train_bot' first."
            ))

        self.stdout.write(self.style.SUCCESS(
            f"{chatbot.name} is ready. Type 'quit' to end the chat."
        ))

        while True:
            try:
                user_text = input("user: ").strip()
            except (KeyboardInterrupt, EOFError):
                # Ctrl+C or Ctrl+D: leave cleanly instead of a traceback.
                self.stdout.write("")
                break

            # Ignore empty lines rather than sending them to the bot.
            if not user_text:
                continue

            if user_text.lower() in EXIT_COMMANDS:
                break

            response = chatbot.get_response(user_text)
            self.stdout.write(f"bot: {response}")

        self.stdout.write("bot: Goodbye!")
