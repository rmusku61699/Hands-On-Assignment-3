"""
Management command: ``python manage.py train_bot``

Trains the chat bot and stores what it learns in the Django database.

Training happens in two steps:
    1. The English corpus shipped with ``chatterbot-corpus`` (greetings,
       conversations, AI, humour, ...) - skipped with ``--no-corpus``.
    2. The project's own conversations from ``chat/training_data.py``,
       which include the sample dialogue from the assignment brief.
"""

from chatterbot.trainers import ChatterBotCorpusTrainer, ListTrainer
from django.core.management.base import BaseCommand

from chat.bot import get_chatbot
from chat.training_data import CUSTOM_CONVERSATIONS


class Command(BaseCommand):
    """Train the ChatterBot instance used by the ``chat`` command."""

    help = "Train the chat bot with the English corpus and custom dialogues."

    def add_arguments(self, parser):
        """Register optional command-line flags."""
        parser.add_argument(
            "--no-corpus",
            action="store_true",
            help="Only train on the custom conversations (faster).",
        )
        parser.add_argument(
            "--reset",
            action="store_true",
            help="Delete everything the bot has learned before training.",
        )

    def handle(self, *args, **options):
        """Entry point executed by ``manage.py``."""
        chatbot = get_chatbot()

        # Optionally wipe the knowledge base so training starts clean.
        if options["reset"]:
            chatbot.storage.drop()
            self.stdout.write("Existing training data removed.")

        # Step 1: the general-purpose English corpus.
        if not options["no_corpus"]:
            self.stdout.write("Training on the ChatterBot English corpus...")
            corpus_trainer = ChatterBotCorpusTrainer(
                chatbot, show_training_progress=False
            )
            corpus_trainer.train("chatterbot.corpus.english")

        # Step 2: our own conversations (trained last so they are included
        # alongside the corpus data).
        self.stdout.write("Training on custom conversations...")
        list_trainer = ListTrainer(chatbot, show_training_progress=False)
        for conversation in CUSTOM_CONVERSATIONS:
            list_trainer.train(conversation)

        total = chatbot.storage.count()
        self.stdout.write(
            self.style.SUCCESS(f"Training complete. {total} statements stored.")
        )
