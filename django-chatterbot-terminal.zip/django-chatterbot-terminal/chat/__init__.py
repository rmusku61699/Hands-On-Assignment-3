"""Terminal chat client built with Django and ChatterBot."""
