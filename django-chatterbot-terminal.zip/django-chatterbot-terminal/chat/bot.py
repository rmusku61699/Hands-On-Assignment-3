"""
Factory for the project's ChatterBot instance.

Keeping bot creation in one place means the ``train_bot`` command, the
``chat`` command and the unit tests all use exactly the same configuration
(taken from ``settings.CHATTERBOT``).
"""

from chatterbot import ChatBot
from django.conf import settings


def get_chatbot(read_only=False):
    """
    Build and return a ChatBot configured from Django settings.

    Args:
        read_only (bool): When True the bot will not learn from the
            conversation (useful for tests and for a "frozen" demo).

    Returns:
        chatterbot.ChatBot: a ready-to-use chat bot backed by Django's DB.
    """
    # Copy the settings so we never mutate the global dictionary.
    config = dict(settings.CHATTERBOT)
    # Drop the name injected by ChatterBot's Django defaults and use ours.
    config.pop("name", None)
    name = getattr(settings, "CHATBOT_NAME", "TerminalBot")
    return ChatBot(name, read_only=read_only, **config)
