"""App configuration for the ``chat`` app."""

from django.apps import AppConfig


class ChatConfig(AppConfig):
    """Holds the terminal chat client and the bot training command."""

    default_auto_field = "django.db.models.BigAutoField"
    name = "chat"
    verbose_name = "Terminal Chat Bot"
