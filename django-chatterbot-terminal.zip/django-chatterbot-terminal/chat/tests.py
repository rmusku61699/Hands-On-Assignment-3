"""
Unit tests for the chat app.

Run with: ``python manage.py test``
Django creates a throw-away test database, so these tests never touch the
real ``db.sqlite3`` file.
"""

from io import StringIO
from unittest.mock import patch

from django.core.management import call_command
from django.test import TestCase

from chat.bot import get_chatbot


class ChatBotTests(TestCase):
    """Check training and the sample conversation from the brief."""

    @classmethod
    def setUpTestData(cls):
        # Train on custom conversations only, to keep the tests fast.
        call_command("train_bot", "--no-corpus", stdout=StringIO())

    def test_training_stores_statements(self):
        """Training should put statements into the Django database."""
        self.assertGreater(get_chatbot().storage.count(), 0)

    def test_sample_conversation(self):
        """The bot reproduces the sample input/output from the assignment."""
        bot = get_chatbot(read_only=True)
        self.assertEqual(
            str(bot.get_response("Good morning! How are you doing?")),
            "I am doing very well, thank you for asking.",
        )
        self.assertEqual(
            str(bot.get_response("You're welcome.")),
            "Do you like hats?",
        )

    def test_chat_command_exits_on_quit(self):
        """The terminal client answers, then stops when the user types quit."""
        out = StringIO()
        user_input = ["Good morning! How are you doing?", "quit"]
        with patch("builtins.input", side_effect=user_input):
            call_command("chat", "--read-only", stdout=out)
        output = out.getvalue()
        self.assertIn("bot: I am doing very well, thank you for asking.",
                      output)
        self.assertIn("bot: Goodbye!", output)
