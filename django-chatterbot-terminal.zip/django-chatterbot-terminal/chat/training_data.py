"""
Custom conversations used to train the bot with ChatterBot's ListTrainer.

Each inner list is one conversation: every statement is treated as the
response to the statement before it. The first conversation is the sample
dialogue from the assignment brief.
"""

CUSTOM_CONVERSATIONS = [
    # Sample input/output from the assignment.
    [
        "Good morning! How are you doing?",
        "I am doing very well, thank you for asking.",
        "You're welcome.",
        "Do you like hats?",
    ],
    [
        "Do you like hats?",
        "Yes, I like hats. Hats keep the sun off my circuits!",
    ],
    [
        "Hello",
        "Hi there! How can I help you today?",
    ],
    [
        "What is your name?",
        "My name is TerminalBot. I was built with Django and ChatterBot.",
    ],
    [
        "What can you do?",
        "I can chat with you. The more we talk, the more I learn.",
    ],
    [
        "What is Django?",
        "Django is a high-level Python web framework that encourages "
        "rapid development and clean, pragmatic design.",
    ],
    [
        "What is ChatterBot?",
        "ChatterBot is a machine-learning based conversational dialog "
        "engine written in Python.",
    ],
    [
        "Thank you",
        "You're welcome.",
    ],
    [
        "Goodbye",
        "Goodbye! It was nice talking to you.",
    ],
]
